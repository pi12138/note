# 定义包内标志性文件

name = 'zzz'

def func1():
	print("这是包的标志性文件__init__.py")
